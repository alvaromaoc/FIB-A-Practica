cd src
make
cd ..
cd compiled
./sacarDatos.sh