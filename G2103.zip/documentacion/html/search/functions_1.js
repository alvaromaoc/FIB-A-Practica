var searchData=
[
  ['gconnected_31',['gConnected',['../class_grafo.html#aee1db4a24cb2bb4a706fc8d3a1a34f5e',1,'Grafo']]],
  ['getcomponentesconexas_32',['getComponentesConexas',['../class_grafo.html#a17293ef7c17b53e0de53bdb000462bcf',1,'Grafo']]],
  ['gfind_33',['gFind',['../class_grafo.html#a8952b055d1ef6acdcdb55fbd439fbc18',1,'Grafo']]],
  ['grafo_34',['Grafo',['../class_grafo.html#ac5e0ea7e4f2ee283108d5c6d0de4e484',1,'Grafo::Grafo(int N, bool A, int q, int D)'],['../class_grafo.html#a787247e6beca9f17d4aa88bf65edb734',1,'Grafo::Grafo(int N, double r, int q)']]],
  ['gunion_35',['gUnion',['../class_grafo.html#a7cfe70c77baff04bfbee680205d0a9f4',1,'Grafo']]]
];
