##Puedes compilar y ejecutar todos los experimentos con **Ejecutar.bat** o **Ejecutar.sh** en función de si usas Linux o Windows.

Si usais Windows
~~~
Ejecutar.bat
~~~

Si usais Linux
~~~
./Ejecutar.sh
~~~