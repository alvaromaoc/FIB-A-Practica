./main.x N N 100 2 10 25 50 100 > ../datos/GrafoNxN_Nodos.csv
echo 1/11
./main.x N A 100 2 10 25 50 100 > ../datos/GrafoNxN_Aristas.csv
echo 2/11
./main.x G 5 100 > ../datos/GrafoG5.csv
echo 3/11
./main.x G 10 100 > ../datos/GrafoG10.csv
echo 4/11
./main.x G 25 100 > ../datos/GrafoG25.csv
echo 5/11
./main.x G 50 100 > ../datos/GrafoG50.csv
echo 6/11
./main.x G 100 100 > ../datos/GrafoG100.csv
echo 7/11
./main.x N N 100 3 10 25 > ../datos/GrafoNxNxN_Nodos.csv
echo 8/11
./main.x N A 100 3 10 25 > ../datos/GrafoNxNxN_Aristas.csv
echo 9/11
./main.x N N 100 4 5 10 > ../datos/GrafoNxNxNxN_Nodos.csv
echo 10/11
./main.x N A 100 4 5 10 > ../datos/GrafoNxNxNxN_Aristas.csv
echo 11/11